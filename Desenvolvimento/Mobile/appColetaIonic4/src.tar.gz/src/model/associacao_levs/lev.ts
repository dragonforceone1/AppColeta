import { Local } from "../coleta/local";

export class lev{
    private id: number;
    private nome: String;
    private endereco: Local;
    private horarioFuncionamento: String;
    private diasFuncionamento: String;

    constructor(id:number, nome: String, endereco: Local, horaFuncionamento: String, diasFuncionamento: String){
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.horarioFuncionamento = horaFuncionamento;
        this.diasFuncionamento = diasFuncionamento;
    }
    public getId(){return this.id;}
    public getNome(){return this.nome;}
    public getEndereco(){return this.endereco;}
    public getHoraFuncionamento(){return this.horarioFuncionamento;}
    public getDiasFuncionamento(){return this.diasFuncionamento;}
    public setId(){return this.id;}
    public setNome(){return this.nome;}
    public setEndereco(){return this.endereco;}
    public setHoraFuncionamento(){return this.horarioFuncionamento;}
    public setDiasFuncionamento(){return this.diasFuncionamento;}
}