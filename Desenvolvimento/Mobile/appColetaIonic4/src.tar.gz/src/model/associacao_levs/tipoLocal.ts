//Enum tipo local//

export enum TipoLocal{
    PORTA = 1,
    LEV = 2,
    ASSOCIACAO= 3
} 