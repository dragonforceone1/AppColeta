//Enum Tipo Visibilidade//

export enum TipoVisibilidade{
    PUBLICA = 0,
    PROTEGIDA = 1,
    PRIVADA = 2
}