//Enum Tipo usuário//

export enum TipoUsuario{
    VISITANTE = 0,
    USUARIO = 1,
    PEV = 2,
    ADMINISTRADOR = 3
}
