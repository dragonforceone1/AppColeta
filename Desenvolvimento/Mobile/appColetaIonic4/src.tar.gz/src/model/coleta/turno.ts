export enum Turno{
    MANHA = 1,
    TARDE = 2,
    NOITE = 3
}
