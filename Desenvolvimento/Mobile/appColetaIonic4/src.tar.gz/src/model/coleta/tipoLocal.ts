
export enum DiaSemana{
    PORTA = 1,
    LEV = 2
}