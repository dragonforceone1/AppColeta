
export enum TipoLixo{
    UMIDO = 0,
    SECO = 1,
    AMBOS = 2
}