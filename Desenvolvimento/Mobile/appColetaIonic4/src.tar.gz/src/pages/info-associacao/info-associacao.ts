import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Unidade } from '../../model/associacao_levs/unidade';
import { HttpProvider } from '../../providers/usuarioProvider';
import { UnidadeProvider } from '../../providers/unidade/unidade';

/**
 * Generated class for the InfoAssociacaoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-info-associacao',
  templateUrl: 'info-associacao.html',
  providers: [
    UnidadeProvider
  ]
})
export class InfoAssociacaoPage {

  public unidade = [];
  nomeunidade:String;

  constructor(public navCtrl: NavController, public navParams: NavParams, private Http: HttpProvider, 
    private unidadeProvide: UnidadeProvider) {
    this.nomeunidade = navParams.get('rotulo');
    this.pesquisarDadosUnidade(navParams.get('rotulo'));
    
  }
  
  pesquisarDadosUnidade(nomeunidade: string){
    this.unidadeProvide.pesquisaUnidade(nomeunidade).then(unidade=>{
      console.log(unidade);
      this.unidade=unidade;
    })
  }



  ionViewDidLoad() {
    console.log('ionViewDidLoad InfoAssociacaoPage');
  }

}
