import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InfoLevPage } from './info-lev';

@NgModule({
  declarations: [
    InfoLevPage,
  ],
  imports: [
    IonicPageModule.forChild(InfoLevPage),
  ],
})
export class InfoLevPageModule {}
